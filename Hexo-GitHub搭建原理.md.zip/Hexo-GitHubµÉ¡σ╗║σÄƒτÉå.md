---
title: Hexo+GitHub搭建原理
comments: false
toc: true
date: 2018-10-28 23:34:28
updated: 2018-10-28 23:34:28
categories: Hexo
tags: 博客
keywords:
author:
cover: https://sghyxp.github.io/img/base_img/4.jpg

---
[TOC]

## githubPages+hexo搭建博客的原理

> 先来了解几个概念：

## 关键词：github pages


github是项目托管网站，列出了项目的源文件，所以github 有一个pages功能，可以自定义主页，用来代替默认的列出源列表的这个页面。github pages 是github提供给用户用来展示个人或者项目主页的静态网页系统。每个用户都可以使用自己的github项目创建，上传静态页面的html文件，github会帮你自动更新你的页面。github Pages可以被认为是用户编写的、托管在github上的静态网页。


### GitHub Pages 官方文档:

1. <https://pages.github.com/>

2. <http://help.github.com/pages>

使用方式：


使用个人或组织页面，需要先创建一个和你的账号同名的仓库，比如我的github账号是sghyxp，那么我需要创建一个名为sghyxp.github.io的repo，然后在master上提交你的项目代码，这样就可以通过网址：http://sghyxp.github.io来访问我的个人博客。



## 关键词：hexo

hexo是基于node环境，所以你需要先安装node，进行一些操作需要用到命令行，所以建议大家直接装一个git bash（mac也有命令），在该环境下，您可以直接用上面提到的命令来安装Node.js。windows下打开它的方法很简单，在任意位置单击右键，选择“GitBash Here”即可。由于Hexo的很多操作都涉及到命令行，您可以考虑始终使用Git Bash来进行操作。 



## 关键词：github 

之前步骤中在Github上创建的那个个人项目的repo（sghyxp.github.io）一个最大的特点就是其master中的html静态文件，可以通过链接http:// .github.io来直接访问。 
Hexo -g 会生成一个静态网站（第一次会生成一个public目录），这个静态文件可以直接访问。 需要将hexo生成的静态网站，提交(git commit)到github上。 



## 关键词：node.js

简单的说 Node.js 就是运行在服务端的 JavaScript。

Node.js 是一个基于Chrome JavaScript 运行时建立的一个平台。

Node.js是一个事件驱动I/O服务端**JavaScript**环境，基于Google的**V8引擎**，V8引擎执行Javascript的速度非常快，性能非常好。

实际意义就是就是既能写前端又能写后端代码。之前超火的一个js项目。目前最多的是用node写中间件。

在本项目中的意义是，**利用依赖于node的前台模板swig文件渲染数据。**

## **总结**：

```flow
st=>start: 创建new xx.md文件:>https://www.baidu.com
op=>operation: 根据node的前端模板swig（hexo自带）或者ejs（hexo自带）渲染数据
op1=>operation: 编译
op2=>operation: 将编译的文件推送到github
op3=>operation: github pages更新托管在github上的静态网页
cond=>condition: Yes or No?
sub=>subroutine: Your Subroutine
e=>end

st->op->op1->op2->op3->e

```


<!---->
<!---->
<!--![æ°æ®æµç¨å¾](http://on0hv7n2x.bkt.clouddn.com/github%20pages%20%E6%95%B0%E6%8D%AE%E6%B5%81.png)-->
